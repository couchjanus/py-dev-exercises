"""todo/__init__.py: Top level module for todo app"""

__app_name__ = "todo"
__version__ = "0.1.0"

TITLE = "Your TODO list" 
# коди повернення
# за допомогою range() призначаємо їм цілі числа.
(
   SUCCESS,
   DIR_ERROR,
   FILE_ERROR,
   DB_READ_ERROR,
   DB_WRITE_ERROR,
   JSON_ERROR,
   ID_ERROR,
) = range(7)

# коди помилок
# словник ERROR відображає коди помилок
# повідомлення про помилки - що відбувається з програмою
# повідомлення про помилки призначені користувачеві.

ERRORS = {
   DIR_ERROR: "config directory error",
   FILE_ERROR: "config file error",
   DB_READ_ERROR: "database read error",
   DB_WRITE_ERROR: "database write error",
   ID_ERROR: "to-do id error",
}
