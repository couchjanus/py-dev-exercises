import typer
from rich.prompt import Prompt
from todo import __app_name__, __version__

def make_title(fn):
   '''This decorator function is a higher order function that takes a function as a parameter'''

   def wrapper():
       func = fn()
       output = func.title()
       return output

   return wrapper

def help_me():
    typer.secho(f"""
    All That You Can Do:
        l : List existing tasks
        a : Add new task
        u : Update existing task
        r : Remove existing task
        h : Print this help
        q : Exit
    """, fg=typer.colors.GREEN)



@make_title
def choose_category():
    return Prompt.ask("[bold green on blue] Choose some category: [/] [bold white on green] Study [/]|[bold white on red] Work [/]|[bold white on yellow] Learn [/]|[bold white on cyan] Sports [/]", default='Work')


def make_your_choice():
    return Prompt.ask("[bold green on blue] Make Your choice (a|l|u|r|q) [/]")

@make_title
def add_your_task():
    return Prompt.ask("[bold green on blue] Text Your task [/]", default='To Do something other')

def bye(TITLE):
	typer.secho(f'Thanks for using {TITLE}. Have a nice day!', fg=typer.colors.GREEN)
