from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt

from todo import __app_name__, __version__, todos, TITLE, ERRORS

from todo.model import Todo
from todo import helpers
from todo import db
from todo import config 

import typer
from pathlib import Path
from typing_extensions import Annotated

app = typer.Typer()
   
console = Console()

header = Todo.make_headers()


def hello():
    console.print(F"[bold magenta]{__app_name__.upper()}[/bold magenta]", chr(128187), F"[bold magenta]version: {__version__}[/bold magenta]")

def show(tasks):

    # console.print(F"[bold magenta]{__app_name__.upper()}[/bold magenta]", chr(128187), F"[bold magenta]version: {__version__}[/bold magenta]")

    # hello()

    table = Table(show_header=True, header_style="bold blue")

    for item in header:
        table.add_column(item['name'], style=item['style'], width=item['width'], min_width=item['min_width'], justify=item['justify'])

    # for idx, task in enumerate(tasks, start=1):
    #     c = Todo.get_category_color(task._category)
    #     is_done_str = Todo.DONE if task._status == 2 else Todo.PENDING
    #     table.add_row(str(idx), task._task, f'[{c}]{task._category}[/{c}]', is_done_str)

    # print(tasks)

    for idx, task in enumerate(tasks, start=1):
        # print(idx, task)
        c = Todo.get_category_color(task['category'])
        is_done_str = Todo.DONE if task['status'] == 2 else Todo.PENDING
        table.add_row(str(idx), task['task'], f'[{c}]{task['category']}[/{c}]', is_done_str)
    console.print(table)



@app.command()
def hello1(name: str):
    print(f"Hello {name}")

@app.command()
def goodbye(name: str, formal: bool = False):
    if formal:
        print(f"Goodbye Ms. {name}. Have a good day.")
    else:
        print(f"Bye {name}!")


    person_name = typer.prompt("What's your name?")
    print(f"Hello {person_name}")

    delete = typer.confirm("Are you sure you want to delete it?")
    if not delete:
        print("Not deleting")
        raise typer.Abort()
    print("Deleting it!")


@app.command()
def init(
#     db_path: Annotated[
#         str,
#         typer.Option("--db-path", "-db", prompt="to-do database location?"),
#     ]=str(db.DEFAULT_DB_FILE_PATH),
# ) -> None:
    db_path: str = typer.Option(str(db.DEFAULT_DB_FILE_PATH), prompt="to-do database location?"))-> None:
    """Initialize the todo database."""
 
    app_init_error = config.init_app(db_path)

    if app_init_error:
        typer.secho(
            f'Creating config file failed with "{ERRORS[app_init_error]}"',
            fg=typer.colors.RED,
        )
        raise typer.Exit(1)
    db_init_error = db.init_database(Path(db_path))
    if db_init_error:
        typer.secho(
            f'Creating database failed with "{ERRORS[db_init_error]}"',
            fg=typer.colors.RED,
        )
        raise typer.Exit(1)
    typer.secho(f"The to-do database is {db_path}", fg=typer.colors.GREEN)


def get_todo_list():
    if config.CONFIG_FILE_PATH.exists():
        db_path = db.get_database_path(config.CONFIG_FILE_PATH)
    else:
        typer.secho(
            'Config file not found. Please, run "todo init"',
            fg=typer.colors.RED,
        )
        raise typer.Exit(1)
    if db_path.exists():
        return todos.TodoList(db_path)
    else:
        typer.secho(
            'Database not found. Please, run "todo init"',
            fg=typer.colors.RED,
        )
        raise typer.Exit(1)



@app.command()
def run():

    todo_list = get_todo_list()
    # todo1 = Todo('To Do something', "Study")
    # todo_list.add(todo1)

    hello()

    while True:
        
        # match Prompt.ask("[bold green on blue] Make Your choice (a|l|u|r|q) [/]"):
        match helpers.make_your_choice():
        # match typer.prompt("Make Your choice(a|l|u|r|q)"):
        
            case 'a':
                # category = Prompt.ask("[bold green on blue] Choose some category: [/] [bold white on green] Study [/]|[bold white on red] Work [/]|[bold white on yellow] Learn [/]|[bold white on cyan] Sports [/]", default='Work')
                # category = helpers.make_your_choice()
                category = helpers.choose_category()
                task = helpers.add_your_task()

                # task = Prompt.ask("[bold green on blue] Text Your task [/]", default='To Do something other')
                # todo2 = Todo('To Do something other', category)
                todo = Todo(task, category)
                todo, error = todo_list.add(todo)

                if error:
                    typer.secho(f'Adding to-do failed with "{ERRORS[error]}"', fg=typer.colors.RED)
                    raise typer.Exit(1)
                else:
                    typer.secho(
                        f"""to-do: "{task}" was added """
                        f"""with category: {category}""",
                        fg=typer.colors.GREEN,
                    )

            case 'l':
                
                tasks, error = todo_list.get_todo_list()

                if error:
                    typer.secho(f'Fetching tasks failed with "{ERRORS[error]}"', fg=typer.colors.RED)
                    raise typer.Exit(1)
                else:
                    if len(tasks) == 0:
                        typer.secho("There are no tasks in the to-do list yet", fg=typer.colors.RED)
                        raise typer.Exit()
                    # print(tasks)
                    show(tasks)
            case 'u':
                todo_list.complete(1)
                tasks = todo_list.get_todo_list()
            case 'r':
                todo_list.delete(1)
            case "q":
                helpers.bye(TITLE)
                break
            case _:
                helpers.help_me()

   
    # print(ord('❌'), chr(ord('❌')))
    # print(ord('✅'), chr(ord('✅')))
    # print(ord("💻"), chr(ord("💻")))

    # creating a NamedTuple
    # todo1 = Todo('To Do something', "Study")
    # todo_list = todos.TodoList()
    # todo_list.add(todo1)
    # tasks = todo_list.get_todo_list()
    # show(tasks)

    # todo_list.complete(1)
    # tasks = todo_list.get_todo_list()
    # print(tasks)
    # show(tasks)
    # # todo_list.delete(1)
    # # tasks = todo_list.get_todo_list()
    # # print(tasks)
    # # show(tasks)
