from pathlib import Path

from todo.model import Todo
from todo.db_handler import DBHandler

from todo import DB_READ_ERROR

class TodoList:

    # def __init__(self) -> None:
    #     self.todo_list = []

    def __init__(self, db_path: Path) -> None:
        self.todo_list = []
        self._db_handler = DBHandler(db_path)

    def add(self, todo:Todo):
        """Add a new to-do to the database."""

        count = len(self.todo_list)
        todo._position = count if count else 0
        
        self.todo_list, read_error = self._db_handler.read_todos()
        
        if read_error == DB_READ_ERROR:
            return (todo, read_error)
        
        self.todo_list.append(todo)

        self.todo_list, write_error = self._db_handler.write_todos(self.todo_list)
        
        return (todo, write_error)

    def get_todo_list(self):
        """Return the current to-do list."""

        self.todo_list = self._db_handler.read_todos()
        return self.todo_list
    
    def delete(self, position: int):
        """Delete current to-do."""

        # indices in UI begin at 1, but in database at 0
        self.todo_list.pop(position-1)
    
    def update(self, position:int, todo: Todo):
        """Update current to-do."""

        self.todo_list[position-1] = todo

    def complete(self, position: int):
        """Complete current to-do."""

        self.todo_list[position-1]._status = 2
    
