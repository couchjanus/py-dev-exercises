"""This module provides the To-Do database functionality."""

from pathlib import Path
import json

from todo import DB_READ_ERROR, DB_WRITE_ERROR, JSON_ERROR, SUCCESS


class DBHandler:
    def __init__(self, db_path: Path) -> None:
        self._db_path = db_path

    def read_todos(self):
        try:
            with self._db_path.open("r") as db:
                try:
                    return (json.load(db), SUCCESS)
                except json.JSONDecodeError:  # Catch wrong JSON format
                    return ([], JSON_ERROR)
        except OSError:  # Catch file IO problems
            return ([], DB_READ_ERROR)

    def write_todos(self, todo_list):
        # print("TODO list >>>>>>>>>>>>>>>>>>>", todo_list)
        try:
            with self._db_path.open("w") as db:
                json.dump(todo_list, db, indent=4)
            return (todo_list, SUCCESS)
        except OSError:  # Catch file IO problems
            return (todo_list, DB_WRITE_ERROR)


if __name__ == "__main__":
    import doctest
    doctest.testmod()