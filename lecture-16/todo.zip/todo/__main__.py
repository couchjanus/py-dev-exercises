"""Todo entry point script"""

from todo import cli, __app_name__


def main():
    cli.app()

if __name__ == "__main__":
    main()
